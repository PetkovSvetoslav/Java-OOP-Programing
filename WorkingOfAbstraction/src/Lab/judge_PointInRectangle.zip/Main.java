import IOUtils.ConsoleReader;
import IOUtils.InputParser;
import geometry.GeometricFactory;
import geometry.Point2D;
import geometry.Rectangle;

public class Main {
    public static void main(String[] args) {
        ConsoleReader reader = new ConsoleReader();

        int[] rectangleInfo = InputParser.parseArray(reader.readLine(), " ");

        Rectangle rectangle = GeometricFactory.createRectangle(rectangleInfo);

        int n = Integer.parseInt(reader.readLine());
        for (int i = 0; i < n; i++) {
            int[] pointCoordinates = InputParser.parseArray(reader.readLine(), " ");
            Point2D point = GeometricFactory.createPoint2D(pointCoordinates);

            System.out.println(rectangle.contains(point));
        }
    }
}
