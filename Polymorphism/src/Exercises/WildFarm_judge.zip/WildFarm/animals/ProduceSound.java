package WildFarm.animals;

public interface ProduceSound {

    void makeSound();
}
