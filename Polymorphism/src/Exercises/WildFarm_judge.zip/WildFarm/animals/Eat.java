package WildFarm.animals;

import WildFarm.food.Food;

public interface Eat {

    void eat(Food food);
}
