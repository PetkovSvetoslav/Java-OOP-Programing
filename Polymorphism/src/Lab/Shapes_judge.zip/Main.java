
public class Main {
    public static void main(String[] args) {

        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(3, 4);

        printShapeInfo(circle);
        System.out.println("<==========>");
        printShapeInfo(rectangle);
    }
    private static void printShapeInfo(Shape shape) {
        System.out.println(shape.calculatePerimeter());
        System.out.println(shape.calculateArea());
    }
}
