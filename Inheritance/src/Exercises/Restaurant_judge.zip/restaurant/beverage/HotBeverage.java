package restaurant.beverage;

import java.math.BigDecimal;

public class HotBeverage extends Beverage {

    public HotBeverage(String name, BigDecimal price, double millilitres) {
        super(name, price, millilitres);
    }
}
