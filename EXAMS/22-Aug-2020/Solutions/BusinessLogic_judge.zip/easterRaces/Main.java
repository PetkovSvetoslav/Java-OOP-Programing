package easterRaces;

import easterRaces.core.ControllerImpl;
import easterRaces.core.EngineImpl;
import easterRaces.core.interfaces.Controller;
import easterRaces.entities.cars.Car;
import easterRaces.entities.drivers.Driver;
import easterRaces.entities.racers.Race;
import easterRaces.io.ConsoleReader;
import easterRaces.io.ConsoleWriter;
import easterRaces.repositories.CarRepository;
import easterRaces.repositories.DriverRepository;
import easterRaces.repositories.RaceRepository;
import easterRaces.repositories.interfaces.Repository;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Repository<Car> motorcycleRepository = new CarRepository();
        Repository<Race> raceRepository = new RaceRepository();
        Repository<Driver> riderRepository = new DriverRepository();

        Controller controller = new ControllerImpl(riderRepository, motorcycleRepository, raceRepository);

        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl(reader, writer, controller);
        engine.run();
    }
}
/*
CreateDriver Michael
CreateDriver Peter
CreateCar Sports Porsche 380
CreateCar Muscle Mustang 580
CreateCar Muscle Corvette 440
CreateRace Daytona 2
AddCarToDriver Michael Porsche
AddCarToDriver Peter Mustang
AddCarToDriver Michael Corvette
StartRace Daytona
AddDriverToRace Daytona Michael
AddDriverToRace Daytona Peter
StartRace Daytona
CreateDriver Brian
AddDriverToRace Daytona Brian
CreateCar Sports Mazda 350
AddCarToDriver Brian Mazda
AddDriverToRace Daytona Brian
StartRace Daytona
End
 */