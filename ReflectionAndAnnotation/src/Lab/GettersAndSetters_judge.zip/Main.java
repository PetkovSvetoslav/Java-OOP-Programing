import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Main {
    public static class MethodComparator implements Comparator<Method> {

        @Override
        public int compare(Method f, Method s) {
            return f.getName().compareTo(s.getName());
        }
    }

    public static void main(String[] args) {


        Class<Reflection> reflectionClass = Reflection.class;
        Method[] declaredMethods = reflectionClass.getDeclaredMethods();

        Set<Method> getters = new TreeSet<>(new MethodComparator());
        Set<Method> setters = new TreeSet<>(new MethodComparator());

        Arrays.stream(declaredMethods)
                .filter(m -> m.getName().contains("get"))
                .forEach(getters::add);

        Arrays.stream(declaredMethods)
                .filter(m -> m.getName().contains("set"))
                .forEach(setters::add);

        System.out.println(
                getters.stream()
                        .map(g -> String.format("%s will return class %s",
                                g.getName(),
                                g.getReturnType().getName().replace("class", "")))
                        .collect(Collectors.joining(System.lineSeparator()))
        );

        System.out.println(
                setters.stream()
                        .map(s -> String.format("%s and will set field of class %s",
                                s.getName(),
                                s.getParameterTypes()[0].getName().replace("class", "")
                        ))
                        .collect(Collectors.joining(System.lineSeparator())));
    }
}
