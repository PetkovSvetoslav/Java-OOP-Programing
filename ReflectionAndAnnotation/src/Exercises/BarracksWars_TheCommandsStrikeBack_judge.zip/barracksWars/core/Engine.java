package barracksWars.core;

import barracksWars.interfaces.*;
import barracksWars.interfaces.Runnable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {
    private static final String COMMANDS_PACKAGE_NAME = "barracksWars.core.commands.";

    private Repository repository;
    private UnitFactory unitFactory;

    public Engine(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(System.in));
        while (true) {
            try {
                String input = reader.readLine();
                String[] data = input.split("\\s+");
                String commandName = data[0];
                String result = interpretCommand(data, commandName);
                if (result.equals("fight")) {
                    break;
                }
                System.out.println(result);
            } catch (RuntimeException e) {
                System.out.println(e.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private String interpretCommand(String[] data, String commandName) {
        try {
            Class<?> clazz = Class.forName(getCommandClassName(COMMANDS_PACKAGE_NAME, commandName));
            Constructor<?> constructor = clazz.getConstructor(String[].class, Repository.class, UnitFactory.class);

            Executable executable = (Executable) constructor.newInstance(data, this.repository, this.unitFactory);
            return executable.execute();

        } catch (ClassNotFoundException
                | NoSuchMethodException
                | InstantiationException
                | IllegalAccessException
                | InvocationTargetException e) {
            e.printStackTrace();
        }

        throw new RuntimeException("Invalid command!");
    }

    private static String getCommandClassName(String path, String commandName) {
        char firstLetter = Character.toUpperCase(commandName.charAt(0));
        String substring = commandName.substring(1);

        return path + firstLetter + substring + "Command";
    }
}
