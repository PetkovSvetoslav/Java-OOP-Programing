package barracksWars.core.commands;

import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public class RetireCommand extends Command {
    public RetireCommand(String[] data, Repository repository, UnitFactory unitFactory) {
        super(data, repository, unitFactory);
    }

    @Override
    public String execute() {
        try {
            String unitType = super.getData()[1];
            super.getRepository().removeUnit(unitType);
            return unitType + " retired!";
        } catch (IllegalStateException e) {
            return e.getMessage();
        }
    }
}
