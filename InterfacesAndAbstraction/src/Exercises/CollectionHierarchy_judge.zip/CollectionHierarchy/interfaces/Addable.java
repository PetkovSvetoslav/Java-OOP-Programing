package CollectionHierarchy.interfaces;

public interface Addable {

    int add(String item);
}
