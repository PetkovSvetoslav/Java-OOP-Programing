package CollectionHierarchy.interfaces;

public interface AddRemovable extends Addable{

    String remove();
}
