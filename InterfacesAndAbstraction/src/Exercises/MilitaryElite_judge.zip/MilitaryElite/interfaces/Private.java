package MilitaryElite.interfaces;

public interface Private extends Soldier {

    double getSalary();
}
