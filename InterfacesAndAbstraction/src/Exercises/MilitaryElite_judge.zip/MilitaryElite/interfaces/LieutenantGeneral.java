package MilitaryElite.interfaces;

public interface LieutenantGeneral {

    void addPrivate(Private priv);
}
