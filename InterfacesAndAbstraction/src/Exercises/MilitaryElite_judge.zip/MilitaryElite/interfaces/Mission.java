package MilitaryElite.interfaces;

import MilitaryElite.enums.State;

public interface Mission {

    String getCodeName();

    State getSate();

    void completeMission();

    boolean isFinished();
}
