package MilitaryElite.interfaces;

public interface Repair {

    String getPartName();

    int getHoursWorked();
}
