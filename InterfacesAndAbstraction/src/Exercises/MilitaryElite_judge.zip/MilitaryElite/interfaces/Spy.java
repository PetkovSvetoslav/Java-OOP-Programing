package MilitaryElite.interfaces;

public interface Spy {

    String getCodeNumber();
}
