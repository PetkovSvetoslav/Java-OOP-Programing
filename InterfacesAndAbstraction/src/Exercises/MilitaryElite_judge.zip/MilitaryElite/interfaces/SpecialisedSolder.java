package MilitaryElite.interfaces;

import MilitaryElite.enums.Corps;

public interface SpecialisedSolder {

    Corps getCorps();
}
